# Apache-PHP Web Server
This is a basic installation to serve web pages in Apache-PHP.


