#!/bin/bash

exec /usr/sbin/apache2 -D FOREGROUND
